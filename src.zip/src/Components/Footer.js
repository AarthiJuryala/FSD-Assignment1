import React from 'react';


function Footer()
{
    return(
          <section class="bg-dark">
             <div class="container">
               <div class="row">  
                <div class="col-sm-12">
                  <h6 class="text-white text-center mb-3 mt-3">Copyright @ Aarthi2022</h6>
                  </div>  
               </div>
             </div>    
          </section>
    
    )
}

export default Footer;
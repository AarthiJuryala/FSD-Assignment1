import React from 'react';

  function Content() {
    return (
       <div>
         <section class="">
              <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active">
                     <img class="d-block w-100" src="Images/bookstack.png" alt="First slide" style={{height:"auto"}}/>
                  </div>
                  <div class="carousel-item">
                     <img class="d-block w-100 " src="Images/bookstack.png" alt="Second slide" style={{height:"auto"}}/>
                  </div>
                  <div class="carousel-item">
                     <img class="d-block w-100" src="Images/bookstack.png" alt="Third slide" style={{height:"auto"}}/>
                  </div>
                </div>
               </div>
        </section>   

        <section class="bg-light" id="intro">
          <div class="container">
            <div class="row">
              <div class="col-sm-12 col-md-12">
                 <h3 class="text-center mt-4 text-secondary">Why should you read?</h3>
               </div>
              </div>
             <div class="row">
                <p class="mt-4 mb-5">Reading fiction is gradually losing its popularity in the technological era. Recent research suggests that reading literary fiction helps people develop empathy, theory of mind, and critical thinking. When we read, we strengthen several different cognitive muscles, so to speak, the EQ. Besides, it is a great way to pass time while also honing your linguistic and imaginative skills. Picking books which are right for you is the first step towards developing a love for reading. Here are some tips to help you start off!</p>
             </div>   
          </div>   
        </section>   

        <section class="" id="personalities">   
         <div class="container">
             <div class="row">
              <div class="col-sm-12 col-md-12">
                 <h3 class="text-center mt-4 text-secondary">Personalities and Genres</h3>
               </div>
              </div>
              <div class="row">
                 <div class="col-sm-4 mb-5">
                    <div class="card mt-4">
                       <img class="card-img-top" src="Images/fantasy.png" alt=""/>
                       <div class="card-body">
                          <h4 class="card-title text-secondary">Fantasy</h4>
                          <p class="card-text text-secondary">If you love visualizing imaginary universes and high-stakes plot lines, this genre is for you!</p>
                       </div>
                    </div>
                 </div>
                 <div class="col-sm-4 mb-5">
                    <div class="card mt-4">
                       <img class="card-img-top" src="Images/r.png" alt=""/>
                       <div class="card-body">
                          <h4 class="card-title text-secondary">Romance</h4>
                          <p class="card-text text-secondary">If you love character dynamics, fuzzy feelings and happy endings, this genre is for you!</p>
                       </div>
                    </div>
                 </div>
                 <div class="col-sm-4 mb-5">
                    <div class="card mt-4">
                       <img class="card-img-top" src="Images/mystery.png" alt=""/>
                       <div class="card-body">
                          <h4 class="card-title text-secondary">Mystery</h4>
                          <p class="card-text text-secondary">If you are analytical and like thinking and using your brain while reading, this genre is for you!</p>
                       </div>
                    </div>
                 </div>
                 <div class="col-sm-4 mb-5">
                    <div class="card mt-4">
                       <img class="card-img-top" src="Images/thriller.png" alt=""/>
                       <div class="card-body">
                          <h4 class="card-title text-secondary">Thriller</h4>
                          <p class="card-text text-secondary">If you like exciting plots and sitting on the edge of your seat throughout the book, this genre is for you!</p>
                       </div>
                    </div>
                 </div>
                 <div class="col-sm-4 mb-5">
                    <div class="card mt-4">
                       <img class="card-img-top" src="Images/scifi.png" alt=""/>
                       <div class="card-body">
                          <h4 class="card-title text-secondary">Sci-fi</h4>
                          <p class="card-text text-secondary">If you are obsessed with the impact of technology on the world, this genre is for you!</p>
                       </div>
                    </div>
                 </div>
                 <div class="col-sm-4 mb-5">
                    <div class="card mt-4">
                       <img class="card-img-top" src="Images/academia.png" alt=""/>
                       <div class="card-body">
                          <h4 class="card-title text-secondary">Dark Academia</h4>
                          <p class="card-text text-secondary">If you love the aesthetic of gothic hallways, robed uniforms and classical music, this genre is for you!</p>
                       </div>
                    </div>
                 </div>
              </div>
        </div>
       </section>  


       <section class=""  id="genres">
        <div class="container">
          <div class="col-sm-12 col-md-12 mb-4">
             <h3 class="text-center text-secondary mt-4">Popular genres</h3>
         </div>
       <div class="accordion" id="accordionExample">
        <div class="card">
         <div class="card-header" id="headingOne">
            <h2 class="mb-0">
            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
               Fantasy
            </button>
            </h2>
         </div>
         <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
            Fantasy is a genre of speculative fiction involving magical elements, typically set in a fictional universe.
            </div>
         </div>
      </div>

      <div class="card">
         <div class="card-header" id="headingTwo">
            <h2 class="mb-0">
            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                Romance
            </button>
            </h2>
         </div>
         <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
            <div class="card-body">
            A romance novel has a central focus on the development of a romantic relationship between people.
            </div>
         </div>
      </div>
      
      <div class="card">
         <div class="card-header" id="headingThree">
            <h2 class="mb-0">
            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
               Mystery
            </button>
            </h2>
         </div>
         <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
            <div class="card-body">
            A mystery novel follows a crime from the moment it is committed to the moment it is solved.
            </div>
         </div>
      </div>
      </div>

      <div class="card">
         <div class="card-header" id="headingFour">
            <h2 class="mb-0">
            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
               Thriller
            </button>
            </h2>
         </div>
         <div id="collapseFour" class="collapse show" aria-labelledby="headingFour" data-parent="#accordionExample">
            <div class="card-body">
            Thrillers give the readers heightened feelings of suspense, excitement, surprise, anticipation and anxiety.
            </div>
         </div>
      </div>

      <div class="card">
         <div class="card-header" id="headingFive">
            <h2 class="mb-0">
            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
               Science fiction
            </button>
            </h2>
         </div>
         <div id="collapseFive" class="collapse show" aria-labelledby="headingFive" data-parent="#accordionExample">
            <div class="card-body">
            Science fiction is a genre of speculative fiction which typically deals with imaginative and futuristic concepts such as advanced science and technology, space exploration, time travel, parallel universes and so on.
            </div>
         </div>
      </div>

      <div class="card">
         <div class="card-header" id="headingSix">
            <h2 class="mb-0">
            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
               Dark Academia
            </button>
            </h2>
         </div>
         <div id="collapseSix" class="collapse show" aria-labelledby="headingSix" data-parent="#accordionExample">
            <div class="card-body">
            Dark academia is a literary and social media aesthetic and subculture concerned with higher education, writing/poetry, the arts, and classic Greek and Gothic architecture.
            </div>
         </div>
      </div>

    </div> 
    </section>

    

   </div>
    );
  }
  
  export default Content;